import glfw
from OpenGL.GL import *
from OpenGL.GLU import *
import numpy as np
from OpenGL.arrays import vbo
import ctypes
CamX = 5
CamY = 5*np.sqrt(2)
#CamY = 0
CamZ = 5
Distance = np.sqrt((CamX*CamX) + (CamY*CamY) + (CamZ*CamZ))


angle = 90

firstX = -5*Distance
secondX = 5*Distance
firstY = -5*Distance
secondY = 5*Distance
firstZ = -5*Distance
secondZ = 5*Distance

X = 0
Y = 0
Z = 0
Upy = 1

pastXpos = 0
pastYpos = 0
currentXpos = 0
currentYpos = 0

Azimuth = 45
Elevation = 45

check = 0


varr = np.array([])
vnarr = np.array([])
iarr = np.array([])
narr = np.array([],'float32')
farr = np.array([])
fnarr = np.array([])
normalarr = np.zeros((len(varr),3), dtype=int)

mode = GL_FILL

def scroll_callback(window, xoffset, yoffset):
    global Distance, CamX, CamY, CamZ, firstX, secondX, firstY, secondY, firstZ, secondZ

    
    Distance -= yoffset
    if Distance < 0:
        Distance = 0.000000000001

    
    CamX = np.sin(Azimuth*np.pi/180)*np.cos(Elevation*np.pi/180)*Distance
    CamY = np.sin(Elevation*np.pi/180)*Distance
    CamZ = np.cos(Azimuth*np.pi/180)*np.cos(Elevation*np.pi/180)*Distance

    firstX = -5*Distance
    secondX = 5*Distance
    firstY = -5*Distance
    secondY = 5*Distance
    firstZ = -5*Distance
    secondZ = 5*Distance
  
        
def cursor_callback(window, xpos, ypos):
    global currentXpos, currentYpos, pastXpos, pastYpos
    pastXpos = currentXpos
    pastYpos = currentYpos
    currentXpos = xpos
    currentYpos = ypos


    
def cursor_callbackA(window, xpos, ypos):
    global xPos, yPos,Upy,CamX, CamY, CamZ, Distance, Azimuth, Elevation, pastXpos, pastYpos, currentXpos, currentYpos 
    pastXpos = currentXpos
    pastYpos = currentYpos
    currentXpos = xpos
    currentYpos = ypos


    Azimuth += (currentXpos - pastXpos)
    Elevation += (currentYpos - pastYpos)


    if Elevation <= -180:
        Elevation += 360

    elif Elevation >= 180:
        Elevation -= 360

    if currentXpos == pastXpos and currentYpos == pastYpos:
        pass


    else:      
        CamX = np.sin(Azimuth*np.pi/180)*np.cos(Elevation*np.pi/180)*Distance
        CamY = np.sin(Elevation*np.pi/180)*Distance
        CamZ = np.cos(Azimuth*np.pi/180)*np.cos(Elevation*np.pi/180)*Distance


        if Elevation < -90:
            Upy = -1

        elif Elevation > 90:
            Upy = -1

        else: Upy = 1


def cursor_callbackB(window, xpos, ypos):
    global xPos, yPos,Upy,CamX, CamY, CamZ, Distance, Azimuth, Elevation, pastXpos, pastYpos, currentXpos, currentYpos, firstX, secondX, firstY, secondY, firstZ, secondZ, X, Y, Z
    pastXpos = currentXpos
    pastYpos = currentYpos
    currentXpos = xpos
    currentYpos = ypos


    pastCamX = CamX
    pastCamY = CamY
    pastCamZ = CamZ

    X1 += (currentXpos - pastXpos)/100
    X2 += (currentXpos - pastXpos)/100
    Y1 += (currentYpos - pastYpos)/100
    Y2 += (currentYpos - pastYpos)/100

        
def cursor_callbackN(window, xpos, ypos):
    pass
    
def button_callback(window, button, action, mod):
    global xPos, yPos,CamX, CamY, CamZ, Distance, Azimuth, Elevation, pastXpos, pastYpos, currentXpos, currentYpos
    yoffset = 0.4
    xpos = 0
    ypos = 0
    check = False
    if action == glfw.PRESS and button==glfw.MOUSE_BUTTON_LEFT:
                glfw.set_cursor_pos_callback(window, cursor_callbackA)
                cursor_callbackA(window, currentXpos, currentYpos)

    if action == glfw.PRESS and button == glfw.MOUSE_BUTTON_RIGHT:
                glfw.set_cursor_pos_callback(window, cursor_callbackB)
                cursor_callbackB(window, currentXpos, currentYpos)

    if action == glfw.RELEASE:
        glfw.set_cursor_pos_callback(window, cursor_callback)
        cursor_callbackN(window, xpos, ypos)

def drop_callback(window, path):
    global varr, vnarr, narr, iarr, farr, fnarr, normalarr
    varr = np.array([])
    vnarr = np.array([])
    narr = np.array([])
    farr = np.array([])
    fnarr = np.array([])
    
    
    filename = path[0].split("\\")
    filename = filename[len(filename)-1]

    print("File name : " + filename)
    
    file = open(path[0], "r")

    face = 0
    face3 = 0
    face4 = 0
    mface = 0
    vcnt = 0
    vncnt = 0

    for line in file:
        if line[0] == 'f':
            if varr.ndim != 2 and vnarr.ndim != 2:
                varr = varr.reshape(vcnt, 3)
                vnarr = vnarr.reshape(vncnt, 3)
            face += 1
            fline = line.split(" ")
            if len(fline) == 4:
                face3 += 1
            elif len(fline) == 5:
                face4 += 1
            else: mface += 1
     
            for i in fline:
                if i == "f":
                    continue
                i = i.split("//")
                #iarr = np.append(iarr, int(i[0]))

                narr = np.append(narr, vnarr[int(i[1])-1])
                narr = np.append(narr, varr[int(i[0])-1])

                farr = np.append(farr, int(i[0])-1)
                fnarr = np.append(fnarr, int(i[1])-1)
                                
        elif line[0] == 'v' and line[1] == ' ':
            vline = line.split(" ")
            a = np.array([float(vline[1]), float(vline[2]), float(vline[3])])
            varr = np.append(varr,a)
            vcnt += 1
            
        elif line[0]+line[1] == "vn":
            vnline = line.split(" ")
            b = np.array([float(vnline[1]), float(vnline[2]), float(vnline[3])])
            vnarr = np.append(vnarr, b)
            vncnt += 1

    farr = farr.reshape(face, 3)
    farr = farr.astype('int')
    normalarr = np.zeros((vcnt,3),dtype = 'float32')
    for i in range(len(farr)):
        normal = np.cross(varr[farr[i][1]] - varr[farr[i][0]],varr[farr[i][2]] - varr[farr[i][0]])

        normalarr[farr[i][0]] += normal
        normalarr[farr[i][1]] += normal
        normalarr[farr[i][2]] += normal

    for i in range(len(varr)):
        normalarr[i] /= np.sqrt(normalarr[i][0]*normalarr[i][0] + normalarr[i][1]*normalarr[i][1] + normalarr[i][2]*normalarr[i][2])

    normalarr = normalarr.astype('float32')

    farr = farr.astype('float32')

    varr = varr.astype('float32')

        
        #print(line)

    print("Total number of faces : " + str(face))
    print("Number of faces with 3 vertices : " + str(face3))
    print("Number of faces with 4 vertices : " + str(face4))
    print("Number of faces with more than 4 vertices : " + str(mface))

    print("")
    narr = narr.reshape(face*6,3)
    narr = narr.astype('float32')


                
def drawLines():
    glBegin(GL_LINES)

    
    glVertex3f(0.,0.,50.)
    glVertex3f(0.,0.,-50.)

    glEnd()
       
def drawGrid():

    for i in range(-50, 50):
            glPushMatrix()
            glTranslatef(i,0,0)
            glBegin(GL_LINES)
            glColor3ub(255,255,255)
            glVertex3f(0,0,50)
            glVertex3f(0,0,-50)
            glEnd()
            glPopMatrix()
    
    for j in range(-50,50):
            glPushMatrix()
            glTranslatef(0,0,j)
            glBegin(GL_LINES)
            glColor3ub(255,255,255)
            glVertex3f(-50,0,0)
            glVertex3f(50,0,0)
            glEnd()
            glPopMatrix()
    
    

def drawFrame():
    glBegin(GL_LINES)
    glColor3ub(255, 0, 0)
    glVertex3fv(np.array([0.,0.,0.]))
    glVertex3fv(np.array([50.,0.,0.]))
    glColor3ub(0, 255, 0)
    glVertex3fv(np.array([0.,0.,0.]))
    glVertex3fv(np.array([0.,50.,0.]))
    glColor3ub(0, 0, 255)
    glVertex3fv(np.array([0.,0.,0]))
    glVertex3fv(np.array([0.,0.,50.]))
    glEnd()

def key_callback(window, key, scancode, action, mods):
    global mode, vnarr, narr, varr, normalarr, farr, fnarr, check
    if action==glfw.PRESS or action==glfw.REPEAT:
        if key==glfw.KEY_Z:
            if mode == GL_LINE:
                mode = GL_FILL
            else:
                mode = GL_LINE

        elif key==glfw.KEY_S:
            if check == 0:
                check = 1
            
            else: check = 0
            
def draw_Cube_glDrawArray():
    global varr, vnarr, iarr, narr, farr, normalarr, check
    glEnableClientState(GL_VERTEX_ARRAY)
    glEnableClientState(GL_NORMAL_ARRAY)
    if check == 0:  
        glNormalPointer(GL_FLOAT, 6*narr.itemsize, narr)
        glVertexPointer(3, GL_FLOAT, 6*narr.itemsize, ctypes.c_void_p(narr.ctypes.data + 3*narr.itemsize))
    #glVertexPointer(3, GL_FLOAT, 6*varr.itemsize, varr)
    #glDrawElements(GL_TRIANGLES, iarr.size, GL_UNSIGNED_INT, iarr)
        glDrawArrays(GL_TRIANGLES, 0, int(narr.size/6))

    else:
        glNormalPointer(GL_FLOAT, 3*normalarr.itemsize, normalarr)
        glVertexPointer(3,GL_FLOAT, 3*varr.itemsize, varr)
        glDrawElements(GL_TRIANGLES, farr.size, GL_UNSIGNED_INT, farr)

    #print(narr.size/6)

def render():
    global CamX, CamY, CamZ, Upy,firstX, secondX, firstY, secondY, firstZ, secondZ, X, Y, Z    
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glEnable(GL_DEPTH_TEST)
    glPolygonMode( GL_FRONT_AND_BACK, mode )
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()

    gluPerspective(90, 1,1,55)
    gluLookAt(CamX, CamY, CamZ, X, Y, Z, 0,Upy,0)

    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()

    
    drawGrid()    
    drawFrame()

    
    glEnable(GL_LIGHTING) 
    glEnable(GL_LIGHT0)

    glEnable(GL_RESCALE_NORMAL)  

    glPushMatrix()

    t = glfw.get_time()

    lightPos = (3.,4.,5.,1.)    
    glLightfv(GL_LIGHT0, GL_POSITION, lightPos)
    glPopMatrix()

    lightColor = (1.,1.,1.,1.)
    ambientLightColor = (.1,.0,.1,1.)
    glLightfv(GL_LIGHT0, GL_DIFFUSE, lightColor)
    glLightfv(GL_LIGHT0, GL_SPECULAR, lightColor)
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambientLightColor)

    objectColor = (1.,0.,1.,1.)
    specularObjectColor = (1.,1.,1.,1.)
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, objectColor)
    glMaterialfv(GL_FRONT, GL_SHININESS, 10)
    glMaterialfv(GL_FRONT, GL_SPECULAR, specularObjectColor)

    glPushMatrix()

    glColor3ub(0, 0, 255)

    draw_Cube_glDrawArray()
    glPopMatrix()

    glDisable(GL_LIGHTING)

    
def main():
    if not glfw.init():
        return
    window = glfw.create_window(480,480,'2017029570-class2',None,None)
    if not window:
        glfw.terminate()
        return
    glfw.set_cursor_pos_callback(window, cursor_callback)
    glfw.set_key_callback(window, key_callback)
    glfw.set_mouse_button_callback(window, button_callback)
    glfw.set_scroll_callback(window, scroll_callback)
    glfw.set_drop_callback(window, drop_callback)
    glfw.make_context_current(window)
    glfw.swap_interval(1)

    while not glfw.window_should_close(window):
        glfw.poll_events()
        render()
        glfw.swap_buffers(window)

    glfw.terminate()

if __name__ == "__main__":
    main()
