import glfw
from OpenGL.GL import *
from OpenGL.GLU import *
import numpy as np
from numpy import linalg
CamX = 5
CamY = 5*np.sqrt(2)
#CamY = 0
CamZ = 5
Distance = np.sqrt((CamX*CamX) + (CamY*CamY) + (CamZ*CamZ))


angle = 90

firstX = -5*Distance
secondX = 5*Distance
firstY = -5*Distance
secondY = 5*Distance
firstZ = -5*Distance
secondZ = 5*Distance

Azimuth = 45
Elevation = 45

X = 0
Y = 0
Z = 0
Upy = 1

pastXpos = 0
pastYpos = 0
currentXpos = 0
currentYpos = 0



legAng = 0
check = 0
leg2Ang = 0
check2 = 0


def scroll_callback(window, xoffset, yoffset):
    global Distance, CamX, CamY, CamZ, firstX, secondX, firstY, secondY, firstZ, secondZ

    
    Distance -= yoffset
    if Distance < 0:
        Distance = 0.000000000001

    
    CamX = np.sin(Azimuth*np.pi/180)*np.cos(Elevation*np.pi/180)*Distance + X
    CamY = np.sin(Elevation*np.pi/180)*Distance + Y
    CamZ = np.cos(Azimuth*np.pi/180)*np.cos(Elevation*np.pi/180)*Distance + Z

  
        
def cursor_callback(window, xpos, ypos):
    global currentXpos, currentYpos, pastXpos, pastYpos
    pastXpos = currentXpos
    pastYpos = currentYpos
    currentXpos = xpos
    currentYpos = ypos


    
def cursor_callbackA(window, xpos, ypos):
    global xPos, yPos,Upy,CamX, CamY, CamZ, Distance, Azimuth, Elevation, pastXpos, pastYpos, currentXpos, currentYpos 
    pastXpos = currentXpos
    pastYpos = currentYpos
    currentXpos = xpos
    currentYpos = ypos


    Azimuth += (currentXpos - pastXpos)
    Elevation += (currentYpos - pastYpos)


    if Elevation <= -180:
        Elevation += 360

    elif Elevation >= 180:
        Elevation -= 360

    if currentXpos == pastXpos and currentYpos == pastYpos:
        pass


    else:      
        CamX = np.sin(Azimuth*np.pi/180)*np.cos(Elevation*np.pi/180)*Distance + X
        CamY = np.sin(Elevation*np.pi/180)*Distance + Y
        CamZ = np.cos(Azimuth*np.pi/180)*np.cos(Elevation*np.pi/180)*Distance + Z


        if Elevation < -90:
            Upy = -1

        elif Elevation > 90:
            Upy = -1

        else: Upy = 1


def cursor_callbackB(window, xpos, ypos):
    global xPos, yPos,Upy,CamX, CamY, CamZ, Distance, Azimuth, Elevation, pastXpos, pastYpos, currentXpos, currentYpos, firstX, secondX, firstY, secondY, firstZ, secondZ, X, Y, Z
    pastXpos = currentXpos
    pastYpos = currentYpos
    currentXpos = xpos
    currentYpos = ypos

    pastCamX = CamX
    pastCamY = CamY
    pastCamZ = CamZ

    X += (currentXpos - pastXpos) * np.cos(Azimuth*np.pi/180) / 100
    Y += (currentYpos - pastYpos)/100
    Z -= (currentXpos - pastXpos)/100 * np.sin(Azimuth*np.pi/180)

    CamX += (currentXpos - pastXpos) * np.cos(Azimuth*np.pi/180) / 100
    CamY += (currentYpos - pastYpos)/100
    CamZ -= (currentXpos - pastXpos) * np.sin(Azimuth*np.pi/180) / 100


        
def cursor_callbackN(window, xpos, ypos):
    pass
    
def button_callback(window, button, action, mod):
    global xPos, yPos,CamX, CamY, CamZ, Distance, Azimuth, Elevation, pastXpos, pastYpos, currentXpos, currentYpos
    yoffset = 0.4
    xpos = 0
    ypos = 0
    check = False
    if action == glfw.PRESS and button==glfw.MOUSE_BUTTON_LEFT:
                glfw.set_cursor_pos_callback(window, cursor_callbackA)
                cursor_callbackA(window, currentXpos, currentYpos)

    if action == glfw.PRESS and button == glfw.MOUSE_BUTTON_RIGHT:
                glfw.set_cursor_pos_callback(window, cursor_callbackB)
                cursor_callbackB(window, currentXpos, currentYpos)

    if action == glfw.RELEASE:
        glfw.set_cursor_pos_callback(window, cursor_callback)
        cursor_callbackN(window, xpos, ypos)

def drawHand():
    global legAng, check, leg2Ang, check2

    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()
    
    t = glfw.get_time()
    # Draw 1
    glPushMatrix()
    glScalef(1,1,0.3)
    drawSphere()
    glPopMatrix()


    if legAng*(180/np.pi) > 0:
        check = 1

    elif legAng*(180/np.pi) < -30:
        check = 0

    if check == 1:
        legAng -= glfw.get_time() - t
        
    else:
        legAng += glfw.get_time() - t

    if leg2Ang*(180/np.pi) > 0:
        check2 = 0

    elif leg2Ang*(180/np.pi) > -10:
        check2 = 1

    if check2 == 1:
        leg2Ang -= glfw.get_time() - t

    else:
        leg2Ang += glfw.get_time() - t

    # Draw 3 of ball
    glPushMatrix()
    glTranslatef(0,1.,0)
    glRotatef(legAng*180/np.pi,1,0,0)

    
    glPushMatrix()
    glScalef(0.2,0.2,0.2)
    drawSphere()
    glPopMatrix()

    # Draw 3 
    glPushMatrix()
    glRotatef(legAng*180/np.pi,1,0,0)
    glTranslatef(0,0.6,0)

    glPushMatrix()
    glScalef(0.3,0.5,0.3)
    drawSphere()
    glPopMatrix()

    # Draw 3 of sub of ball
    glPushMatrix()
    glTranslatef(0,0.5,0)
    glRotatef(legAng*180/np.pi,1,0,0)
    

    glPushMatrix()
    glScalef(0.2,0.2,0.2)
    drawSphere()
    glPopMatrix()

    # Draw 3 of sub
    glPushMatrix()
    glRotatef(legAng*180/np.pi,1,0,0)
    glTranslatef(0,0.4,0)

    glPushMatrix()
    glScalef(0.2,0.35,0.2)
    drawSphere()
    glPopMatrix()
    glPopMatrix()
    glPopMatrix()
    glPopMatrix()
    glPopMatrix()

    # Draw 2 of ball
    glPushMatrix()
    glRotatef(23,0,0,1)
    glTranslatef(-np.cos(np.radians(67)), np.sin(np.radians(67)), 0)
    glRotatef(legAng*180/np.pi,1,0,0)

    glPushMatrix()
    glScalef(0.2,0.2,0.2)
    drawSphere()
    glPopMatrix()

    # Draw 2
    glPushMatrix()
    glRotatef(legAng*180/np.pi,1,0,0)
    glTranslatef(0,0.6,0)

    glPushMatrix()
    glScalef(0.3,0.45,0.3)
    drawSphere()
    glPopMatrix()

    # Draw 2 of sub of ball
    glPushMatrix()
    glTranslatef(0,0.45,0)
    glRotatef(legAng*180/np.pi,1,0,0)

    glPushMatrix()
    glScalef(0.2,0.2,0.2)
    drawSphere()
    glPopMatrix()

    # Draw 2 of sub
    glPushMatrix()
    glRotatef(legAng*180/np.pi,1,0,0)
    glTranslatef(0,0.35,0)

    glPushMatrix()
    glScalef(0.2,0.3,0.2)
    drawSphere()
    glPopMatrix()
    glPopMatrix()
    glPopMatrix() 
    glPopMatrix()
    glPopMatrix()

    # Draw 1 of ball
    glPushMatrix()
    glRotatef(55,0,0,1)
    glTranslatef(-np.cos(np.radians(55)), np.sin(np.radians(55)), 0)
    glRotatef(legAng*180/np.pi,1,0,0)

    glPushMatrix()
    glScalef(0.2,0.2,0.2)
    drawSphere()
    glPopMatrix()

    # Draw 1
    glPushMatrix()
    glRotatef(legAng*180/np.pi,1,0,0)
    glTranslatef(0,0.3,0)

    glPushMatrix()
    glScalef(0.25,0.3,0.25)
    drawSphere()
    glPopMatrix()

    # Draw 1 of sub of ball
    glPushMatrix()
    glTranslatef(0,0.3,0)
    glRotatef(legAng*180/np.pi,1,0,0)

    glPushMatrix()
    glScalef(0.15,0.15,0.15)
    drawSphere()
    glPopMatrix()

    # Draw 1 of sub
    glPushMatrix()
    glRotatef(legAng*180/np.pi,1,0,0)
    glTranslatef(0,0.2,0)

    glPushMatrix()
    glScalef(0.2,0.25,0.2)
    drawSphere()
    glPopMatrix()
    glPopMatrix()
    glPopMatrix() 
    glPopMatrix()
    glPopMatrix()

    # Draw 4 of ball
    glPushMatrix()
    glRotatef(-23,0,0,1)
    glTranslatef(np.cos(np.radians(67)), np.sin(np.radians(67)), 0)
    glRotatef(legAng*180/np.pi,1,0,0)

    glPushMatrix()
    glScalef(0.2,0.2,0.2)
    drawSphere()
    glPopMatrix()

    # Draw 4
    glPushMatrix()
    glRotatef(legAng*180/np.pi,1,0,0)
    glTranslatef(0,0.6,0)

    glPushMatrix()
    glScalef(0.3,0.45,0.3)
    drawSphere()
    glPopMatrix()

    # Draw 4 of sub of ball
    glPushMatrix()
    glTranslatef(0,0.45,0)
    glRotatef(legAng*180/np.pi,1,0,0)

    glPushMatrix()
    glScalef(0.2,0.2,0.2)
    drawSphere()
    glPopMatrix()

    # Draw 4 of sub
    glPushMatrix()
    glRotatef(legAng*180/np.pi,1,0,0)
    glTranslatef(0,0.35,0)

    glPushMatrix()
    glScalef(0.2,0.3,0.2)
    drawSphere()
    glPopMatrix()
    glPopMatrix()
    glPopMatrix() 
    glPopMatrix()
    glPopMatrix()

    # Draw 5 of ball
    glPushMatrix()
    glRotatef(-30,0,0,1)
    glTranslatef(np.cos(np.radians(30)), np.sin(np.radians(30)), 0)
    glRotatef(legAng*180/np.pi,1,0,0)

    glPushMatrix()
    glScalef(0.2,0.2,0.2)
    drawSphere()
    glPopMatrix()

    # Draw 5
    glPushMatrix()
    glRotatef(legAng*180/np.pi,1,0,0)
    glTranslatef(0,0.3,0)

    glPushMatrix()
    glScalef(0.2,0.3,0.2)
    drawSphere()
    glPopMatrix()

    # Draw 5 of sub of ball
    glPushMatrix()
    glTranslatef(0,0.3,0)
    glRotatef(legAng*180/np.pi,1,0,0)

    glPushMatrix()
    glScalef(0.15,0.15,0.15)
    drawSphere()
    glPopMatrix()

    # Draw 5 of sub
    glPushMatrix()
    glRotatef(legAng*180/np.pi,1,0,0)
    glTranslatef(0,0.3,0)

    glPushMatrix()
    glScalef(0.15,0.2,0.15)
    drawSphere()
    glPopMatrix()
    glPopMatrix()
    glPopMatrix() 
    glPopMatrix()
    glPopMatrix()
                
def drawLines():
    glBegin(GL_LINES)

    glVertex3f(0.,0.,50.)
    glVertex3f(0.,0.,-50.)

    glEnd()
       
def drawGrid():

    for i in range(-50, 50):
            glPushMatrix()
            glTranslatef(i,0,0)
            glBegin(GL_LINES)
            glVertex3f(0,0,50)
            glVertex3f(0,0,-50)
            glEnd()
            glPopMatrix()



    
    for j in range(-50,50):
            glPushMatrix()
            glTranslatef(0,0,j)
            glBegin(GL_LINES)
            glVertex3f(-50,0,0)
            glVertex3f(50,0,0)
            glEnd()
            glPopMatrix()
    
    

def drawFrame():
    glBegin(GL_LINES)
    glColor3ub(255, 0, 0)
    glVertex3fv(np.array([0.,0.,0.]))
    glVertex3fv(np.array([50.,0.,0.]))
    glColor3ub(0, 255, 0)
    glVertex3fv(np.array([0.,0.,0.]))
    glVertex3fv(np.array([0.,50.,0.]))
    glColor3ub(0, 0, 255)
    glVertex3fv(np.array([0.,0.,0]))
    glVertex3fv(np.array([0.,0.,50.]))
    glEnd()

def drawSphere(numLats=12, numLongs=12):
    for i in range(0, numLats + 1):
        lat0 = np.pi * (-0.5 + float(float(i-1) / float(numLats)))
        z0 = np.sin(lat0)
        zr0 = np.cos(lat0)

        lat1 = np.pi * (-0.5 + float(float(i) / float(numLats)))
        z1 = np.sin(lat1)
        zr1 = np.cos(lat1)

        glBegin(GL_QUAD_STRIP)

        for j in range(0, numLongs + 1):
            lng = 2 * np.pi * float(float(j-1) / float(numLongs))
            x = np.cos(lng)
            y = np.sin(lng)
            glVertex3f(x * zr0, y * zr0, z0)
            glVertex3f(x * zr1, y * zr1, z1)

        glEnd()
        

def render():
    global CamX, CamY, CamZ, Upy,firstX, secondX, firstY, secondY, firstZ, secondZ, X, Y, Z
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glEnable(GL_DEPTH_TEST)
    glPolygonMode( GL_FRONT_AND_BACK, GL_LINE )
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()

    gluPerspective(90, 1,1,55)
    gluLookAt(CamX, CamY, CamZ, X, Y, Z, 0,Upy,0)

    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()
    
    
    drawFrame()

    glColor3ub(255,255,255)
    drawGrid()
    drawHand()

    
def main():
    if not glfw.init():
        return
    window = glfw.create_window(480,480,'2017029570-class1',None,None)
    if not window:
        glfw.terminate()
        return
    glfw.set_cursor_pos_callback(window, cursor_callback)
    glfw.set_mouse_button_callback(window, button_callback)
    glfw.set_scroll_callback(window, scroll_callback)
    glfw.make_context_current(window)

    while not glfw.window_should_close(window):
        glfw.poll_events()
        render()
        glfw.swap_buffers(window)

    glfw.terminate()

if __name__ == "__main__":
    main()
