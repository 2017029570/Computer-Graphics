import glfw
from OpenGL.GL import *
from OpenGL.GLU import *
import numpy as np
from OpenGL.arrays import vbo
import ctypes
CamX = 25
CamY = 25*np.sqrt(2)
CamZ = 25
Distance = np.sqrt((CamX*CamX) + (CamY*CamY) + (CamZ*CamZ))


angle = 90

firstX = -5*Distance
secondX = 5*Distance
firstY = -5*Distance
secondY = 5*Distance
firstZ = -5*Distance
secondZ = 5*Distance

X = 0
Y = 0
Z = 0
Upy = 1

pastXpos = 0
pastYpos = 0
currentXpos = 0
currentYpos = 0

Azimuth = 45
Elevation = 45

check = 0

mode = GL_FILL

joints = np.array([])
motion = np.array([])

check1 = 0
nframe = 0
r = 0
offset = np.array([])
def scroll_callback(window, xoffset, yoffset):
    global Distance, CamX, CamY, CamZ, firstX, secondX, firstY, secondY, firstZ, secondZ

    
    Distance -= yoffset
    if Distance < 0:
        Distance = 0.000000000001

    
    CamX = np.sin(Azimuth*np.pi/180)*np.cos(Elevation*np.pi/180)*Distance
    CamY = np.sin(Elevation*np.pi/180)*Distance
    CamZ = np.cos(Azimuth*np.pi/180)*np.cos(Elevation*np.pi/180)*Distance

    firstX = -5*Distance
    secondX = 5*Distance
    firstY = -5*Distance
    secondY = 5*Distance
    firstZ = -5*Distance
    secondZ = 5*Distance
  
        
def cursor_callback(window, xpos, ypos):
    global currentXpos, currentYpos, pastXpos, pastYpos
    pastXpos = currentXpos
    pastYpos = currentYpos
    currentXpos = xpos
    currentYpos = ypos


    
def cursor_callbackA(window, xpos, ypos):
    global xPos, yPos,Upy,CamX, CamY, CamZ, Distance, Azimuth, Elevation, pastXpos, pastYpos, currentXpos, currentYpos 
    pastXpos = currentXpos
    pastYpos = currentYpos
    currentXpos = xpos
    currentYpos = ypos


    Azimuth += (currentXpos - pastXpos)
    Elevation += (currentYpos - pastYpos)


    if Elevation <= -180:
        Elevation += 360

    elif Elevation >= 180:
        Elevation -= 360

    if currentXpos == pastXpos and currentYpos == pastYpos:
        pass


    else:      
        CamX = np.sin(Azimuth*np.pi/180)*np.cos(Elevation*np.pi/180)*Distance
        CamY = np.sin(Elevation*np.pi/180)*Distance
        CamZ = np.cos(Azimuth*np.pi/180)*np.cos(Elevation*np.pi/180)*Distance


        if Elevation < -90:
            Upy = -1

        elif Elevation > 90:
            Upy = -1

        else: Upy = 1


def cursor_callbackB(window, xpos, ypos):
    global xPos, yPos,Upy,CamX, CamY, CamZ, Distance, Azimuth, Elevation, pastXpos, pastYpos, currentXpos, currentYpos, firstX, secondX, firstY, secondY, firstZ, secondZ, X, Y, Z
    pastXpos = currentXpos
    pastYpos = currentYpos
    currentXpos = xpos
    currentYpos = ypos

    pastCamX = CamX
    pastCamY = CamY
    pastCamZ = CamZ

    X += (currentXpos - pastXpos) * np.cos(Azimuth*np.pi/180) / 100
    Y += (currentYpos - pastYpos)/100
    Z -= (currentXpos - pastXpos)/100 * np.sin(Azimuth*np.pi/180)

    CamX += (currentXpos - pastXpos) * np.cos(Azimuth*np.pi/180) / 100
    CamY += (currentYpos - pastYpos)/100
    CamZ -= (currentXpos - pastXpos) * np.sin(Azimuth*np.pi/180) / 100


        
def cursor_callbackN(window, xpos, ypos):
    pass
    
def button_callback(window, button, action, mod):
    global xPos, yPos,CamX, CamY, CamZ, Distance, Azimuth, Elevation, pastXpos, pastYpos, currentXpos, currentYpos
    yoffset = 0.4
    xpos = 0
    ypos = 0
    check = False
    if action == glfw.PRESS and button==glfw.MOUSE_BUTTON_LEFT:
                glfw.set_cursor_pos_callback(window, cursor_callbackA)
                cursor_callbackA(window, currentXpos, currentYpos)

    if action == glfw.PRESS and button == glfw.MOUSE_BUTTON_RIGHT:
                glfw.set_cursor_pos_callback(window, cursor_callbackB)
                cursor_callbackB(window, currentXpos, currentYpos)

    if action == glfw.RELEASE:
        glfw.set_cursor_pos_callback(window, cursor_callback)
        cursor_callbackN(window, xpos, ypos)

def drop_callback(window, path):
    global joints, motion, nframe, check1, offset
    check1 = 0
    motion = []
    joints = []
    offset = []
    filename = path[0].split("\\")
    filename = filename[len(filename)-1]

    print("File name : " + filename)

    fmode = ""
    file = open(path[0], "r")
    value = np.array([])
    dic = {}

    njoint = 0
    name = []
    for line in file:
        line = line.lstrip()
        line = line.split(" ")
        
        if fmode != "MOTION":
            if line[0] == "ROOT":
                dic['NAME'] = line[1]
                name = np.append(name, line[1])
                fmode = "ROOT"
                njoint += 1
                joints = np.append(joints, dic)
                dic = {}

            elif line[0] == "JOINT":
                dic['NAME'] = line[1]
                name = np.append(name, line[1])
                fmode = "JOINT"
                njoint += 1
                joints = np.append(joints, dic)
                dic = {}
                
            elif line[0] == "End" and line[1] == "Site\n":
                fmode = "End Site"
                dic['MODE'] = "End Site"
                joints = np.append(joints, dic)
                dic = {}
                
            elif line[0] == "{\n":
                joints = np.append(joints, "{")

            elif line[0] == "}\n":
                joints = np.append(joints, "}")

     
            elif line[0] == "OFFSET":
                for i in range(1,len(line)):
                    offset = np.append(offset,np.abs(float(line[i])))
                    value = np.append(value, float(line[i]))
                dic[line[0]] = value

                value = []
                
                if fmode == "End Site":
                    joints = np.append(joints, dic)
                    dic = {}
                    
            elif line[0] == "CHANNELS":
                dic['NUM OF CHANNELS'] = int(line[1])
                for i in range(2,len(line)):
                    value = np.append(value, line[i].lower())        
                dic[line[0]] = value
                value = []

                
                if fmode != "End Site":
                    joints = np.append(joints, dic)
                    dic = {}
            if line[0] == "MOTION\n":
                fmode = "MOTION"


        elif fmode == "MOTION":
            if line[0] == "Frames:":
                nframe = int(line[1])
            elif line[0] == "Frame":
                tframe = float(line[2])

            else:
                motion = np.append(motion, line[:-1])
    
    motion = motion.reshape(nframe, int(motion.size/nframe))

    motion = motion.astype('float64')

    print("Number of frames : " + str(nframe))
    print("FPS : " + str(tframe))
    print("Number of joints : " + str(njoint))

    print("List of all joint names : ")
    print(name)
    

def drawBVH():
    global joints, offset, gVertexArraySeparate
    if joints.size == 0:
        return
    glMatrixMode(GL_MODELVIEW)
    
    glLoadIdentity()
    glPushMatrix()

    i = 0
    while i<joints.size:
        if type(joints[i]) == type("{") and joints[i] == "{":
            glPushMatrix()
            
            value = joints[i+1]["OFFSET"]

            sqr = value*value
            l = np.sqrt(sqr[0]+sqr[1]+sqr[2])
            if np.abs(value).max() == np.abs(value[0]):
                x = np.array([0,value[0]])
                y = np.array([-offset.mean()*offset.mean()/offset.max()*4, offset.mean()*offset.mean()/offset.max()*4])
                z = np.array([-offset.mean()*offset.mean()/offset.max()*4, offset.mean()*offset.mean()/offset.max()*4])
            elif np.abs(value).max() == np.abs(value[1]):
                x = np.array([-offset.mean()*offset.mean()/offset.max()*4, offset.mean()*offset.mean()/offset.max()*4])
                y = np.array([0,value[1]])
                z = np.array([-offset.mean()*offset.mean()/offset.max()*4,offset.mean()*offset.mean()/offset.max()*4])
            elif np.abs(value).max() == np.abs(value[2]):
                x = np.array([-offset.mean()*offset.mean()/offset.max()*4,offset.mean()*offset.mean()/offset.max()*4])
                y = np.array([-offset.mean()*offset.mean()/offset.max()*4, offset.mean()*offset.mean()/offset.max()*4])
                z = np.array([0,value[2]])


            
            gVertexArraySeparate = createVertexArraySeparate(x, y, z)
            drawLines()
            glTranslatef(value[0], value[1], value[2])
            
 
             
            i += 1

        elif type(joints[i]) == type("}") and joints[i] == "}":
            
            glPopMatrix()
            
        i += 1
    glPopMatrix()

def moveBVH(r):
    global joints, motion, nframe, gVertexArraySeparate
    if joints.size == 0:
        return
    glMatrixMode(GL_MODELVIEW)
    
    

    I = np.array([0.,0.,0])
    i = 0

    c = 0
    glLoadIdentity()
    glPushMatrix()
    
    while i<joints.size:
        if type(joints[i]) == type("{") and joints[i] == "{":
            glPushMatrix()
            value = joints[i+1]["OFFSET"]

            l = np.sqrt(value[0]*value[0]+value[1]*value[1]+value[2]*value[2])
            x = np.array([-offset.mean()*offset.mean()/offset.max()*4, offset.mean()*offset.mean()/offset.max()*4])
            y = np.array([-offset.mean()*offset.mean()/offset.max()*4, offset.mean()*offset.mean()/offset.max()*4])
            z = np.array([-offset.mean()*offset.mean()/offset.max()*4, offset.mean()*offset.mean()/offset.max()*4])            

            if np.abs(value).max() == np.abs(value[0]):
                x = np.array([0, value[0]])
               
            if np.abs(value).max() == np.abs(value[1]):
                y = np.array([0, value[1]])
                
            if np.abs(value).max() == np.abs(value[2]):
                z = np.array([0, value[2]])
            
            gVertexArraySeparate = createVertexArraySeparate(x, y, z)

            drawLines()
            glTranslatef(value[0], value[1], value[2])
            
            if len(list(joints[i+1].keys())) == 3:
                chan = joints[i+1]["CHANNELS"]
                for k in range(0,joints[i+1]["NUM OF CHANNELS"]):
                    if chan[k] == "xposition":
                        glTranslatef(motion[r][c], 0, 0)

                    elif chan[k] == "yposition":
                        glTranslatef(0,motion[r][c],0)
                    elif chan[k] == "zposition":
                        glTranslatef(0,0,motion[r][c])


                    elif chan[k] == "xrotation":
                        glRotatef(motion[r][c], 1, 0, 0)

                    elif chan[k] == "yrotation":
                        glRotatef(motion[r][c], 0, 1, 0)

                    elif chan[k] == "zrotation":
                        glRotatef(motion[r][c], 0, 0, 1)

                    c += 1

            

            x = y = z = None
            
            i += 1

        elif type(joints[i]) == type("}") and joints[i] == "}":   
            glPopMatrix()
                
        i += 1
    glPopMatrix()

def createVertexArraySeparate(x, y, z):
    varr = np.array([
            (0,0,1),         # v0 normal
            ( x[0] ,  y[1] ,  z[1] ), # v0 position
            (0,0,1),         # v2 normal
            (  x[1] , y[0] ,  z[1] ), # v2 position
            (0,0,1),         # v1 normal
            (  x[1] ,  y[1] ,  z[1] ), # v1 position

            (0,0,1),         # v0 normal
            ( x[0] ,  y[1] ,  z[1] ), # v0 position
            (0,0,1),         # v3 normal
            ( x[0] , y[0] ,  z[1] ), # v3 position
            (0,0,1),         # v2 normal
            (  x[1] , y[0] ,  z[1] ), # v2 position

            (0,0,-1),
            ( x[0] ,  y[1] , z[0] ), # v4
            (0,0,-1),
            (  x[1] ,  y[1] , z[0] ), # v5
            (0,0,-1),
            (  x[1] , y[0] , z[0] ), # v6

            (0,0,-1),
            ( x[0] ,  y[1] , z[0] ), # v4
            (0,0,-1),
            (  x[1] , y[0] , z[0] ), # v6
            (0,0,-1),
            ( x[0] , y[0] , z[0] ), # v7

            (0,1,0),
            ( x[0] ,  y[1] ,  z[1] ), # v0
            (0,1,0),
            (  x[1] ,  y[1] ,  z[1] ), # v1
            (0,1,0),
            (  x[1] ,  y[1] , z[0] ), # v5

            (0,1,0),
            ( x[0] ,  y[1] ,  z[1] ), # v0
            (0,1,0),
            (  x[1] ,  y[1] , z[0] ), # v5
            (0,1,0),
            ( x[0] ,  y[1] , z[0] ), # v4

            (0,-1,0),
            ( x[0] , y[0] ,  z[1] ), # v3
            (0,-1,0),
            (  x[1] , y[0] , z[0] ), # v6
            (0,-1,0),
            (  x[1] , y[0] ,  z[1] ), # v2

            (0,-1,0),
            ( x[0] , y[0] ,  z[1] ), # v3
            (0,-1,0),
            ( x[0] , y[0] , z[0] ), # v7
            (0,-1,0),
            (  x[1] , y[0] , y[0] ), # v6

            (1,0,0),
            (  x[1] ,  y[1] ,  z[1] ), # v1
            (1,0,0),
            (  x[1] , y[0] ,  z[1] ), # v2
            (1,0,0),
            (  x[1] , y[0] , z[0] ), # v6

            (1,0,0),
            (  x[1] ,  y[1] ,  z[1] ), # v1
            (1,0,0),
            (  x[1] , y[0] , z[0] ), # v6
            (1,0,0),
            (  x[1] ,  y[1] , z[0] ), # v5

            (-1,0,0),
            ( x[0] ,  y[1] ,  z[1] ), # v0
            (-1,0,0),
            ( x[0], y[0], z[0] ), # v7
            (-1,0,0),
            ( x[0], y[0],z[1] ), # v3

            (-1,0,0),
            ( x[0] ,  y[1] ,  z[1] ), # v0
            (-1,0,0),
            ( x[0] ,  y[1] , z[0] ), # v4
            (-1,0,0),
            ( x[0] , y[0] , z[0] ), # v7
            ], 'float32')
    return varr
    

def drawLines():
    global gVertexArraySeparate
    varr = gVertexArraySeparate
    glEnableClientState(GL_VERTEX_ARRAY)
    glEnableClientState(GL_NORMAL_ARRAY)
    glNormalPointer(GL_FLOAT, 6*varr.itemsize, varr)
    glVertexPointer(3, GL_FLOAT, 6*varr.itemsize, ctypes.c_void_p(varr.ctypes.data + 3*varr.itemsize))
    glDrawArrays(GL_TRIANGLES, 0, int(varr.size/6))

       
def drawGrid():

    for i in range(-50, 50,5):
            glPushMatrix()
            glTranslatef(i,0,0)
            glBegin(GL_LINES)
            glColor3ub(255,255,255)
            glVertex3f(0,0,50)
            glVertex3f(0,0,-50)
            glEnd()
            glPopMatrix()
    
    for j in range(-50,50,5):
            glPushMatrix()
            glTranslatef(0,0,j)
            glBegin(GL_LINES)
            glColor3ub(255,255,255)
            glVertex3f(-50,0,0)
            glVertex3f(50,0,0)
            glEnd()
            glPopMatrix()
    
    

def drawFrame():
    glBegin(GL_LINES)
    glColor3ub(255, 0, 0)
    glVertex3fv(np.array([0.,0.,0.]))
    glVertex3fv(np.array([50.,0.,0.]))
    glColor3ub(0, 255, 0)
    glVertex3fv(np.array([0.,0.,0.]))
    glVertex3fv(np.array([0.,50.,0.]))
    glColor3ub(0, 0, 255)
    glVertex3fv(np.array([0.,0.,0]))
    glVertex3fv(np.array([0.,0.,50.]))
    glEnd()

def key_callback(window, key, scancode, action, mods):
    global mode, vnarr, narr, varr, normalarr, farr, fnarr, check1
    if action==glfw.PRESS or action==glfw.REPEAT:
        if key==glfw.KEY_SPACE:
            check1 = 1
                        
            
def render():
    global CamX, CamY, CamZ, Upy,firstX, secondX, firstY, secondY, firstZ, secondZ, X, Y, Z, check1,r, nframe
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glEnable(GL_DEPTH_TEST)
    glPolygonMode( GL_FRONT_AND_BACK, mode )
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()

    gluPerspective(90, 1,1,100)
    gluLookAt(CamX, CamY, CamZ, X, Y, Z, 0,Upy,0)

    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()

    
    drawGrid()    
    drawFrame()

    glEnable(GL_LIGHTING) 
    glEnable(GL_LIGHT0)

    glEnable(GL_RESCALE_NORMAL)  

    glPushMatrix()

    t = glfw.get_time()

    lightPos = (3.,4.,5.,1.)    
    glLightfv(GL_LIGHT0, GL_POSITION, lightPos)
    glPopMatrix()

    lightColor = (1.,1.,1.,1.)
    ambientLightColor = (.1,.0,.1,1.)
    glLightfv(GL_LIGHT0, GL_DIFFUSE, lightColor)
    glLightfv(GL_LIGHT0, GL_SPECULAR, lightColor)
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambientLightColor)

    objectColor = (1.,0.,1.,1.)
    specularObjectColor = (1.,1.,1.,1.)
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, objectColor)
    glMaterialfv(GL_FRONT, GL_SHININESS, 10)
    glMaterialfv(GL_FRONT, GL_SPECULAR, specularObjectColor)

    glPushMatrix()

    glColor3ub(0, 0, 255)

    if check1 == 0:
        drawBVH()
    else:
        if r >= nframe:
            r = 0
        moveBVH(r)
        r += 1
    glPopMatrix()

    glDisable(GL_LIGHTING)

gVertexArraySeparate = None    
def main():
    global gVertexArraySeparate
    if not glfw.init():
        return
    window = glfw.create_window(480,480,'2017029570-class3',None,None)
    if not window:
        glfw.terminate()
        return
    glfw.set_cursor_pos_callback(window, cursor_callback)
    glfw.set_key_callback(window, key_callback)
    glfw.set_mouse_button_callback(window, button_callback)
    glfw.set_scroll_callback(window, scroll_callback)
    glfw.set_drop_callback(window, drop_callback)
    glfw.make_context_current(window)
    glfw.swap_interval(1)

    
    while not glfw.window_should_close(window):
        glfw.poll_events()
        render()
        glfw.swap_buffers(window)

    glfw.terminate()

if __name__ == "__main__":
    main()
